## Configs for nightly builds

The configurations in the directory is being used for the nightly job to build the images for GCE.

The script that runs is [ci-gce-nightly.sh](../../../../scripts/ci-gce-nightly.sh)
