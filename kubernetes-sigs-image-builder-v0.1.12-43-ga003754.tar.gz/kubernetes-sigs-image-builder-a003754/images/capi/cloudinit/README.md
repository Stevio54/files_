# Cloud-init Test Data

The files in this directory:

* **Are** example data used for testing
* Are **not** included in any of the images
* Should **not** be used in production systems
