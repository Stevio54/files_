This role is to be used for operating systems that require some operations
that require a reboot.
