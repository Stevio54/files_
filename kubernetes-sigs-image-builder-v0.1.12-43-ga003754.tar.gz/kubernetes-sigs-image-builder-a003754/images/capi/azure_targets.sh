VHD_TARGETS="ubuntu-1804 ubuntu-2004 centos-7 windows-2019 windows-2019-containerd windows-2022-containerd"
SIG_TARGETS="ubuntu-1804 ubuntu-2004 centos-7 windows-2019 windows-2019-containerd windows-2022-containerd flatcar"
SIG_GEN2_TARGETS="ubuntu-1804 ubuntu-2004 centos-7 flatcar"
