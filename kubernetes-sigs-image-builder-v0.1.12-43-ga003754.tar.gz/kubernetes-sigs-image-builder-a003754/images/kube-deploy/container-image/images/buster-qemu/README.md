The buster-qemu image is intended for rapid image development.

It sets a root password: `root`, which makes it unsuitable for public
deployments.