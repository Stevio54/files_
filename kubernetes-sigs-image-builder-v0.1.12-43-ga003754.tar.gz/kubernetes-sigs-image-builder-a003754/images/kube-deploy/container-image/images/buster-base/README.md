`buster-base` is the base image containing common functionality for buster.
