buster-aws creates the buster image for AWS; it is derived from
`buster-base` and adds AWS specific configurations.
