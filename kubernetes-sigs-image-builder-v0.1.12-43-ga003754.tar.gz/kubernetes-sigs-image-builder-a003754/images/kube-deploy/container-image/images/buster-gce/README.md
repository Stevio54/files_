buster-gce creates the buster image for GCE; it is derived from
`buster-base` and adds GCE specific configurations.
