# kube-deploy

This is a repository of community maintained Kubernetes cluster deployment
automations.

Think of this as https://github.com/kubernetes/contrib for deployment
automations! Each subdirectory is its own project. It should be a place where
people can come see how the community is deploying kubernetes and should allow
for faster development iteration compared to developing in the main repository.
